package laughingbelchindustries.fartstarbeta;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.os.Environment;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.content.Context;
import android.util.Log;
import java.io.IOException;

public class MainScreen extends AppCompatActivity {
    public final static String EXTRA_MESSAGE = "Hey wow! Message!";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
    }
    public void EnterStar(View EnterView){
        //Write code for entering website here
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        EditText editText = (EditText) findViewById(R.id.edit_message);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    public void QuickTakeRecorder(View QuickTakeView){
        //OnClick when the 'fastplay' button is pressed
        QuickTakePlayer FastPlay = new QuickTakePlayer();

    }
}
